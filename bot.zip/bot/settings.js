const fs = require('fs');
const chalk = require('chalk');

global.botName = 'Pjarr'; // Nama Bot Kamu
global.ownerNumber = '6287731931654'; // Nomor Kamu
global.ownerName = 'pajarr'; // Nama Kamu
global.website = 'https://www.jarrpjar.my.id'; // Web Kamu
global.wagc = 'https://www.jarrpjar.my.id'; // Web Kamu

global.packname = botName; // Nama Pack
global.author = ownerName; // Nama Author
global.footer = '© 2025 •PAJAR';
global.creator = '6287731931654@s.whatsapp.net'; // Nomor Creator
global.premium = ['6287731931654']; // User Premium
global.prefa = '.'; // Prefix
global.tempatDB = 'database.json'; // Tempat Database

global.saluran = '0@newsletter'; // ID Saluran Kamu
global.saluranName = ownerName; // Nama Saluran Kamu
global.sessionName = 'session'; // Nama Folder Sesi Bot Kamu

global.panel = ''; // Link Panel Kamu
global.cred = ''; // API PTLA Kamu
global.apiuser = ''; // API PTLC Kamu
global.eggs = '15'; // Eggs Number (Recommended)
global.nets = '5'; // Nets Number (Recommended)
global.location = '1'; // Location Number (Recommended)

global.typereply = 'v4'; // Gaya Reply v1-v4
global.autoblocknumber = '62'; // Auto Block Number
global.antiforeignnumber = '62'; // Anti Foreign Number
global.welcome = false // Auto Welcome Msg
global.anticall = true // Anti Call
global.autoswview = true // Auto View Status
global.adminevent = false // Admin Event Msg
global.groupevent = false // Group Event Msg
global.notifRegister = false // Notif Register
global.onlyRegister = false // Hanya Pendaftar
global.autoClearSesi = false // Otomatis hapus file sesi setiap 1 jam
global.autoClearTmp = true // Otomatis hapus file temp setiap 1 jam

global.payment = {
	dana: "0812-3456-7890",
	gopay: "0812-3456-7890",
	ovo: "0812-3456-7890",
	qris: "https://image-url.com",
	shopeePay: "0812-3456-7890",
	seabank: "0812-3456-7890"
};

global.limit = {
	free: 10, // Limit User Non-premium
	premium: 1000, // Limit User Premium
	vip: "VIP" // Limit User VIP 👑
};

global.uang = {
	free: 10000, // Uang User Non-premium
	premium: 1000000, // Uang User Premium
	vip: 1000000 // Uang User VIP 👑
};

global.bot = {
	limit: 0, // Limit Awal Bot
	uang: 0 // Uang Awal Bot
};

global.game = {
	suit: {}, // Sesi Game Suit
	menfes: {}, // Sesi Menfess
	tictactoe: {}, // Sesi Tictactoe
	kuismath: {}, // Sesi Kuis Mathematics
	tebakbom: {}, // Sesi Tebak Bom
};

global.mess = {
	admin: "khusus sng ndue",
	botAdmin: "Mora harus jadi admin dulu biar bisa jalanin ini! 😭",
	done: "uws",
	error: "sek ene sng eror ki",
	group: "fitur khusus grup ",
	limit: "hee, ws tkan limit koe \n\nBayar sek nk pengen nggo mneh, hahaha suwon",
	noCmd: "koe ngakon opto kang? aku ki ra pham",
	nsfw: "Fitur NSFW dimatikan di grup ini, coba minta izin ke admin dulu ya~ ",
	owner: "khusus sng ndue",
	premium: "Bayar sek mas bro",
	private: "chat pribadi yee, ojo nk kne saru",
	success: "yeeee isoo",
	wait: "sek nteni dilutt ga suiiii, nteni ya sbarr"
};

global.imageDonasi = "https://8030.us.kg/file/G0roqHOrpn5o.jpg"; // Url Image Donasi (dana, qris etc..)
global.imageUrl = "https://8030.us.kg/file/G0roqHOrpn5o.jpg"; // Url Image
global.imageBuffer = fs.readFileSync("./media/image.jpg"); // Buffer Image

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})